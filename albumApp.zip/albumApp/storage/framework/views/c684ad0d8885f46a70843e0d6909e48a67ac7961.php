<?php $__env->startSection('container'); ?>
    <h1><?php echo e($enterprise); ?></h1>
    <?php if(isset($message)): ?>
        <div class="alert alert-<?php echo e($type); ?>" role="alert">
            <?php echo e($message); ?>

        </div>
    <?php endif; ?>
    <table class="table table-striped">
    <thead>
        <tr>
            <th scope="col">#Id</th>
            <th scope="col">Name</th>
            <th scope="col">Price</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <p><?php echo e($resource['id']); ?></p>
                    
                </td>
                <td>
                    <?php echo e($resource['name']); ?>

                </td>
                <td>
                    <?php echo e($resource['priece'].'€'); ?>

                </td>
                <td>
                    <form class="deleteForm" action="<?php echo e(url('resource/' . $resource['id'])); ?>" method="get">
                        <input type="submit" value="Show"/>
                    </form>
                </td>
                <td>
                    <form class="deleteForm" action="<?php echo e(url('resource/' . $resource['id'] . '/edit')); ?>" method="get">
                        <input type="submit" value="Edit"/>
                    </form>
                </td>
                <td>
                    <form class="deleteForm" action="<?php echo e(url('resource/' . $resource['id'])); ?>" method="post">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="submit" value="Delete"/>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<a href="<?php echo e(url('resource/create')); ?>" class="btn btn-primary btn-lg" type="button">Add new product</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/albumApp/resources/views/resource/index.blade.php ENDPATH**/ ?>