<?php $__env->startSection('footer'); ?>
<div class="container">
    &copy; Bootstrap
    </div>
<?php echo $__env->yieldSection(); ?><?php /**PATH /var/www/html/laraveles/albumApp/resources/views/base/footer.blade.php ENDPATH**/ ?>