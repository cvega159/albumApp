<?php $__env->startSection('container'); ?>
<h1><?php echo e($enterprise); ?></h1>

<form action="<?php echo e(url('resource/' . $resource['id'])); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <input value="<?php echo e(old('name')); ?>" type="text" name="name" placeholder="Name of the product" min-length="5" max-length="30" required />
    <input value="<?php echo e(old('priece')); ?>" type="number" name="priece" placeholder="Price of the product" min="1" step="0.01" required />
    <input type="submit" value="Edit"/>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/albumApp/resources/views/resource/edit.blade.php ENDPATH**/ ?>