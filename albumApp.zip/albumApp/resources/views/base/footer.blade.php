@section('footer')
<div class="container">
    &copy; Bootstrap
    </div>
@show